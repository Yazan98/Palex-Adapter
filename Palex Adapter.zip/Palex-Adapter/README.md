# Palex-Adapter
Android RecyclerView Adapter Library to Build Multiple Views with Kotlin Syntax, Pagination
