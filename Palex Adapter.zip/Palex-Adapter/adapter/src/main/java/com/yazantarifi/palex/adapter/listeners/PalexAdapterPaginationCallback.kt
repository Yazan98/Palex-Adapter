package com.yazantarifi.palex.adapter.listeners

interface PalexAdapterPaginationCallback {

    fun onNextPageRequest()

}