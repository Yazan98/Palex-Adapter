package com.yazantarifi.palex.adapter.data

interface PalexItem {

    fun getItemViewType(): Int

}
