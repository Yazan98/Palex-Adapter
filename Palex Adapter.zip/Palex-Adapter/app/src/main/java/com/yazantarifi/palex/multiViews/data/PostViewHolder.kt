package com.yazantarifi.palex.multiViews.data

import android.view.View
import androidx.recyclerview.widget.RecyclerView

open class PostViewHolder constructor(view: View): RecyclerView.ViewHolder(view)
